export class Center {
    centerId:number;
    centerName:string;
    centerLocation:string;
    test:Test[];
}
export class Test {
    testId:number;
    testName:string;
}

