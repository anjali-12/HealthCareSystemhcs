import { Component, OnInit } from '@angular/core';
import {Center} from '../center'; 
import {CentersService} from '../centers.service';

@Component({
  selector: 'app-deletecenter',
  templateUrl: './deletecenter.component.html',
  styleUrls: ['./deletecenter.component.css']
})
export class DeletecenterComponent implements OnInit {
  centerId:number;
  msg:String;
  errorMsg:String;
  submitted=false;
  
 
 
  constructor(private centersService:CentersService) { }

  ngOnInit() {
      
  }
  deleteCenter(){
    console.log(this.centerId);
    this.centersService.deleteCenter(this.centerId).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      },
      error => {
        alert("This ID does not Exist");        
      });
  }
  OnSubmit(){
    this.submitted=true;
    this.deleteCenter();
  }
   
  
}
