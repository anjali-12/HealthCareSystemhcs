import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Center } from './center';
@Injectable({
  providedIn: 'root'
})
export class CentersService {
 
  
  constructor(private http:HttpClient) { }
  
  
  viewCenters():Observable<any>{
    return this.http.get(`http://localhost:6767/`+'centers');
  }
 addCenters(center: Center):Observable<any> {
    return this.http.post(`http://localhost:6767/`+'addcenter', center,{responseType:'text'});
  }
  deleteCenter(centerId: number): Observable<any> {  
    return this.http.delete(`http://localhost:6767/center/${centerId}`,{responseType:'text'});
   
  }  
 
  UpdateCenter(modifyCenter: Center) {
    return this.http.put("http://localhost:6767/update",modifyCenter,{responseType:'text'});
    
  }
  
}
