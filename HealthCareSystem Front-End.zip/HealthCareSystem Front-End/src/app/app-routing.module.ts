import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ViewcenterComponent} from './viewcenter/viewcenter.component';
import {AddcenterComponent} from './addcenter/addcenter.component';

import {DeletecenterComponent} from './deletecenter/deletecenter.component';



const routes: Routes = [
  {path:'viewcenter',component :ViewcenterComponent},
  {path:'addcenter',component :AddcenterComponent},
  {path:'deletecenter',component :DeletecenterComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
